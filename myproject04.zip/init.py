# coding=utf-8

class Person:

    def __init__(self, name, age):
        self.name = name
        self.age = age
        print(self.name,self.age)

    def move(self):
        print("移动")

    def test(self):
        print("姓名:{}".format(self.name))
        print("年龄:{}".format(self.age))

student = Person("张三",18)
# student.move()
# student.test()