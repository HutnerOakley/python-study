# coding=utf-8
import chardet

#读取txt文件
file = open(r'F:\project\myproject04\file\test.txt')
# file1 = open('/file/test.txt')
# print(file.read(5))
f = file.read().encode() #将str类型字符串以utf8格式编码，获得bytes类型的对象
# +
print(chardet.detect(f)) #查看文件f以什么编码格式编码的
print(file.read(5))
file.close()

#读取图片文件

# file1 = open("file/img.png","rb")
# f = file1.read()
# print(f)
# file1.close()


