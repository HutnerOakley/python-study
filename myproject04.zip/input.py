x = int(input("请输入第一个数"))
# str1 = input("您需要进行的运算")
# y = int(input("请输入第二个数"))

for i in range(1, x+1):
    for j in range(1, i + 1):
        print("%d*%d=%d"%(j,i,(j*i)),end=' ')
    print()

