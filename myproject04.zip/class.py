# coding=utf-8



class Animal(object):

    def move(self):
        print("正在移动")

    def sleep(self):
        print("睡觉")


# 给对象添加属性,以及对应的属性值
dog = Animal()
cat = Animal()
dog.name = "旺财"
dog.age = 3

print("狗的名字:{}".format(dog.name))
print("狗的年龄：{}".format(dog.age))

cat.sleep()
cat.move()
