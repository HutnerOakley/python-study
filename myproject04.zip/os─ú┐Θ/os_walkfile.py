# coding=utf-8

import os.path
import time

jsonpath = r'F:\python\Lib\json'
jsonpath1 = r'F:\python\Lib\json\__pycache__'

#目录下只有文件可以直接使用os.listdir方法来读取文件
for i in os.listdir(jsonpath1):
    print(os.path.join(jsonpath1, i))

#目录下既有文件又有子目录，就需要使用os.walk方法
'''
os.walk方法返回三个对象，遍历的目录路径，目录名，文件名
'''
for root, dirs, files in os.walk(jsonpath):
    print(root,type(root))
    print(dirs,type(dirs))
    print(files,type(files))

    #遍历子目录
    for i in dirs:
        print(os.path.join(jsonpath, i))

    #遍历文件
    for i in files:
        print(os.path.join(jsonpath, i))
