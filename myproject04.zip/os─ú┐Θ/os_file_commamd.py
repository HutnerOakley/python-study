# coding=utf-8

import os


path = '.'

os.path.abspath(path) #返回path的绝对路径
os.path.dirname(path) #返回path中的目录名称
os.path.basename(path) #返回path文件名
os.path.exists('test') #判断test文件是否存在

print(os.path.abspath(__file__)) #获取当前文件的绝对路径
print(os.path.dirname(__file__)) #获取当前文件所在目录的目录名
print(os.path.basename(__file__)) #返回当前文件的文件名
print(os.path.exists('test'))

test="test.py"
path1 = os.path.abspath(__file__)
print(os.path.join(path1,test))
