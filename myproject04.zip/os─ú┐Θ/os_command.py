# coding=utf-8

import os


path1 = os.getcwd() #获取当前py文件所在的目录路径
print(path1)
file = os.listdir('../') #列出指定目录下的所有文件和目录，包含隐藏文件
print(file)
os.makedirs(name='test/test1') #在当前python文件所在的目录中创建多层目录
# os.remove('test') #递归删除空目录
os.mkdir('test2') #创建单级目录
os.rename('test','test3') #重命名目录/文件

path2 = '.'

os.path.abspath(path2)
os.path.basename(path2)
os.path.dirname(path2)

