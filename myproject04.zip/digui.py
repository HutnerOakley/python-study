# coding=utf-8


# 不断除了2，直到商为0，输出这个过程中每次得到的商的值
def fun(n):
    m = n // 2  # 保留整数
    print(m)  # 每次求商，输出商的值
    if m == 0:
        '''当商为0时，停止，返回Done'''
        return 1
    else:
        fun(m)  # 递归调用，函数内自己调用自己


fun(20)


# 求阶乘
"""
阶乘就是5!=5*4*3*2*1
n!=n*(n-1)*(n-2)...*1
找到这个式子规律 f(n) = f(n-1)*n
这个规律的式子就是我们的递归表达式
我们递归的边界条件时f(1)=1,当n=1时，递归结束。
"""


# def fun1(n):
#     m = 0
#     if n == 1:
#         return 1
#     else:
#         m = fun1(n - 1) * n
#         return m
#
# print(fun1(4))


# 非波那锲数列
# def fun2(n):
#     if n == 1 or n == 2:
#         return 1
#     else:
#         return fun2(n - 1) + fun2(n - 2)
#
#
# print(fun2(55))
