# print("hello world", end=' ')
# print("hello")
#
# f = open("./file/demo.txt","w")
# print("hello world",file=f)
# print("松上",file=f)
# f.close()


# print("100是否大于100",100>100)
# print("34是否等于34.0",34==34.0)
# print("False是否小于True",False<True)
# print("True是否大于等于2",True >= 2)

# a = 1
# b = 1
# print(a is b)
# print(a == b)
#
# a = "string"
# b = "string"
# print(a is b)
# print(a == b)
#
# a = (1,2,3)
# b = (1,2,3)
# print(a is b)
# print(a == b)
#
# a = [1,2,3]
# b = [1,2,3]
# print(a is b)
# print(a == b)

# string="helloWorld"
# print(list(string))
#
# list=[1,2,3,4,5,6,7]
# print(list[1])
# print(list[::-1])
# print(list[0:-1])
# print(list[::2])
# print(list[-2:-1])
#
# list.append(8)
# print(list)

# list = ["C","JAVA","PHP","C++"]
# list1 = ["qwe","asd","zxc"]
# list.append(list1)
# print(list)
# list.extend(list1)
# print(list)
# list.insert(2,list1)
# print(list)
#
#
# scores = {"数学":95,"英语":90,"语文":84}
# print(scores)

# know = ['语文',"英语","数学"]
# dict1 = dict.fromkeys(know,100)
# print(dict1)


# list1 = [("one",1),("two",2),("three",3)]
# dict1 = dict(list1)
# print(dict1)
# dict2 = dict(key1="test1",key2="test2")
# print(dict2)
#
# print(dict2.get("key1"))
#
# print(dir(dict))


# set = {1,2,2,3,4,5,5,6,6,}
# print(set)

# list = [1,1,2,2,3,3,4,4,5]
# print(set(list))
# set1 = set(list)
# print(set1)
# set1.add(7)
# print(set1)



# set1 = {1,2,3,4,5}
# set2 = {4,5,6,7,8}
# set3 = set1.difference(set2)
# print(set3)
# set4 = set1.intersection(set2)
# print(set4)
# set5 = set1.union(set2)
# print(set5)

str = "qwqertyuiopasdfghjkl"
print(len(str))

str1 = "学习python"
print(len(str1))
print(len(str1.encode("utf-8")))


list1 = ["a","b","c","d","e"]
print("".join(list1))

name = "hello"
age = 18
print("%s %d"%(name,age))
print("%o" %10) #八进制
print("%d" %10) #十进制
print("%x" %10) #十六进制


print("你好{}这个{}".format("hello","world")) #直接用{}占位
print("{0}""{1}".format("hello","world"))  #带编号
print("{1}""{1}{0}".format("hello","world"))
print("{name} {age} {name}".format(name="hello",age=18)) #带关键字


name = "Jack"
age = 18
print(f"name{name} age{age}")

print(f"number={20*8+10}")
name = "JACK"
print(f"name{name.lower()}")

list = ["a","b","c","d","e"]
for i in range(len(list)):
    print(i,list[i])

for i ,j in enumerate(list):
    print(i,j)


l1 = [i for i in range(1,101)]
print(l1)

for i in range(1,101):
    print(i)

l2 = [1,2,3,4,5,6,7,8]
print([i * 2 for i in l2])
print([i*2 for i in l2 if i>5])

dict1 = {"a":1,"b":2,"c":3,"d":4}
print({j:i for i,j in dict1.items()})

# set1 = {1,2,3,4}
set1 = {2,1,3,4}
print({ i*2 for i in set1})

set2=set()
for i in set1:
    j = i *2
    set2.add(j)
print(set2)