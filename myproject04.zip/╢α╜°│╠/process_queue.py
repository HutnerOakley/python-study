#coding=utf-8

import multiprocessing
import time


def download(q):
    '''
    模拟下载数据
    :param q: q为一个队列对象
    '''
    data = [1,2,3,4]

   #向队列中写入数据
    for i in data:
        q.put(i)

    print("下载器已经下载完毕数据，并将数据存入到队列中")

def modify(q):
    '''
    数据处理
    :param q:
    '''
    new_data=list()
    time.sleep(1)

    #从队列中获取数据
    while True:
        data = q.get()
        print(data)
        new_data.append(data)

        if q.empty():
            break

    #对数据进行处理
    print(new_data)

def func():
    # 1.创建一个队列
    q = multiprocessing.Queue()

    # 2.创建多个线程，将队列对象作为参数传递到子线程中
    p1 = multiprocessing.Process(target=download,args=(q,))
    p2 = multiprocessing.Process(target=modify,args=(q,))

    p1.start()
    p2.start()

if __name__ == '__main__':
    func()

