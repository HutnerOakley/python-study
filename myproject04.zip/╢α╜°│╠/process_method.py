#coding=utf-8

import multiprocessing
import os
import time


def fun():
    '''
    利用os来获取进程的pid和父进程的ppid
    利用current_process()来获取当前进程对象，然后获取当前进程对象的pid
    '''
    print("子进程的pid为：%d,父进程ppid为：%d" %(os.getpid(),os.getppid()))
    time.sleep(2)
    print("子进程%s %s结束" %(multiprocessing.Process().name,multiprocessing.current_process().pid))

def fun1():
    print("启动子进程...")
    for i in range(1,11):
        p = multiprocessing.Process(target=fun,name="Processtest-%d" %i)
        p.start()
        # join方法等待子进程结束之后才执行其他进程
        # p.join()
        # terminate方法设置为守护进程,不管子进程是否完成，立即结束
        # p.terminate()

    print("结束子进程...")

if __name__ == '__main__':
    fun1()
