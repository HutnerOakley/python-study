#coding=utf-8

import multiprocessing
import time


def func1(data):
    time.sleep(1)
    print(data*data)

if __name__ == '__main__':
    '''
    顺序执行，使用map并发执行，使用apply_async()并发执行
    '''
    #顺序执行
    lis = [1,2,3,4,5,6]
    # print("顺序执行:") #也就是串行执行，单进程
    # before = time.time()
    # for i in lis:
    #     func1(i)
    # after = time.time()
    # print("顺序执行时间：%f 秒" %(after - before))

    #使用map并发执行
    # print('使用map并行执行:')  #创建多个进程，并行执行
    # pool = multiprocessing.Pool(3)
    # before = time.time()
    # pool.map(func1,lis) #map()方法是将func1这个函数对象，应用于lis这个可迭代对象中的每个元素上
    # pool.close() #关闭进程池，不再接受新的进程
    # pool.join()  #主进程阻塞等待子进程的退出
    # after = time.time()
    # print("并行执行时间：%f 秒" %(after - before))


    #使用apply_async()并发执行
    print('使用apply_async并行执行:') #创建多个进程，并行执行
    pool = multiprocessing.Pool(3) #创建拥有3个进程数量的进程池
    before = time.time()
    # lis:要处理的数据列表，func1：处理lis列表中数据的函数
    for i in lis:
        pool.apply_async(func1,args=(i,))
    pool.close() #关闭进程池，不再接受新的进程
    pool.join()  #主进程阻塞等待子进程的退出
    after = time.time()
    print("并行执行时间：%f 秒" % (after - before))

