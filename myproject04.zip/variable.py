# coding=utf-8

test = "hello world"


def func2():
    print("函数内部访问:{}".format(test))


func2()
print("函数外访问：{}".format(test))

test_str = "hello"
def func3():
    global test_str
    test_str = "战神"
    print("函数中访问：%s" %test_str)
func3()
print("函数外访问：%s" %test_str)


def func():
    b = 20  # b是局部变量
    print(b)


func()


# 函数的参数也是局部变量，只能在函数中使用
def func1(name, age):
    print(name, age)


func1("zahngsan", 18)
