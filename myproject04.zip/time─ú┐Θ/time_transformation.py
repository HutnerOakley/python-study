# coding=utf-8

import time

#将struct_time对象转换格式化时间字符串
'''
将时间元祖格式化输出吗，如果不传入时间元祖，默认为当前时间
'''
t1 = time.strftime("%Y-%m-%d %H:%M:%S")
print(t1)
t2 = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
print(t2)


#将字符串转换为struct_time对象
'''
根据格式规范将一个字符串转换为时间元祖对象
'''
time_str = "2020-10-01 08:00:00"
t3 = time.strptime(time_str,"%Y-%m-%d %H:%M:%S")
print(t3)
