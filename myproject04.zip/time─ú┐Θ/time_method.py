#coding=utf-8

import time

t1 = time.time() #获取时间戳
print(t1)
time.sleep(2)

t2 = time.localtime() #获取时间元祖
print(t2)

print(time.localtime(t1)) #将时间戳转换为时间元祖

print(time.mktime(t2)) #把时间元祖转换为时间戳

t3 = time.asctime() #获取时间字符串
print(t3)

print(time.ctime(t1)) #将时间戳转换为时间字符串

