#coding=utf-8

with open(r"F:\project\myproject04\file\demo.txt") as f:
    print(f.read())
    print(f.tell()) #文件指针的位置
    f.seek(0) #seek()函数改变文件指针到文件开头
    print(f.read(1))