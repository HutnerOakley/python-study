# coding=utf-8

file = open(r"F:\project\myproject04\file\test.txt")
f=file.readline(5)
print(f)
file.close()

