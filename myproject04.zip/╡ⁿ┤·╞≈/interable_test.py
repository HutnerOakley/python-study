#coding=utf-8

from collections.abc import Iterable

a = "hellowolrd"
print(isinstance(a,Iterable)) #判断是否为可迭代的对象
print(isinstance((1,2,3),Iterable))
print(isinstance(100,Iterable))