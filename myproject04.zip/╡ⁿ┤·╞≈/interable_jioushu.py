#coding=utf-8


class Number(object):
    def __init__(self):
        self.num=2

    def __iter__(self):
        return self

    def __next__(self):
        val = self.num
        if val>=10:
            raise StopIteration
        self.num+=2
        return val


num = Number()
print(num.__next__())
print(num.__next__())
print(num.__next__())
print(num.__next__())
# for i in num:
#     print(i)
