#coding=utf-8
import threading
import time

lockA = threading.Lock()
lockB = threading.Lock()


class MyThreadA(threading.Thread):
    def run(self):
        #对锁A进行上锁
        lockA.acquire()

        print("在A类中对%s线程，执行A上锁操作--" % self.name)

        #等待1.5s
        time.sleep(1.5)

        #对锁B进行上锁，会堵塞，因为已经被其它线程上锁了
        #设置超时时间来避免堵塞,超出超时时间会释放这把锁,所以需要捕获异常
        lockB.acquire(timeout=3)

        print("在A类中对%s线程，执行B上锁操作--" % self.name)

        #释放B锁
        try:
            lockB.release()
        except:
            print()
        print("A类中对%s线程，释放B锁" % self.name)

        #释放A锁
        lockA.release()
        print("A类中对%s线程，释放A锁" % self.name)



class MyThreadB(threading.Thread):

    def run(self):

        # 对锁B进行上锁
        lockB.acquire()
        print("在B类中对%s线程，执行B上锁操作--" % self.name)

        # 等待1.5s
        time.sleep(1.5)

        # 对锁A进行上锁，会堵塞，因为已经被其它线程上锁了
        lockA.acquire()

        print("在B类中对%s线程，执行A上锁操作" % self.name)

        # 释放A锁
        lockA.release()
        print("B类中对%s线程，释放A锁" % self.name)

        # 释放B锁
        try:
            lockB.release()
        except Exception:
            print()
        print("B类中对%s线程，释放B锁" % self.name)


def test():
    t1 = MyThreadA()
    t1.start()

    t2 = MyThreadB()
    t2.start()


if __name__ == '__main__':
    test()