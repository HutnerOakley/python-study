#coding=utf-8

import time
import threading


def func1():
    for i in range(0,3):
        time.sleep(1)
        print("func1")

before = time.time()
t = threading.Thread(target=func1)
# t.setDaemon(True)
t.start()
# t.join()

# func1()
print("helloworld")
# time.sleep(2)
print("end...")
after = time.time()
print("花费时间%f"%(after-before))