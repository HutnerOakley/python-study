#coding=utf-8

import time
import threading

def run_time(func):
    def wrapper():
        before = time.time()
        print("{} start: {}".format(func.__name__,time.strftime("%X",time.localtime())))
        func()
        print("%s end: %s" %(func.__name__,time.strftime("%X",time.localtime())))
        after = time.time()
        print("%s 程序执行用了%f" %(func.__name__,after-before))

    return wrapper


@run_time
def func1():
    time.sleep(1)
    print("func1 执行了")
    time.sleep(2)


@run_time
def func2():
    time.sleep(1)
    print("func2 执行了")
    time.sleep(2)


if __name__ == '__main__':
    before = time.time()
    t1 = threading.Thread(target=func1) #threading.Thread()函数创建多线程
    t1.start() #启动线程
    #func1()
    #func2()
    t2 = threading.Thread(target=func2)
    t2.start()
    after = time.time()
    print("执行两个函数花费了%.3f"%(after-before))
