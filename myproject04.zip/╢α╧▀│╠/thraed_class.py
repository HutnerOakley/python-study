#coding=utf-8


import threading
import time

class MyThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    #重写父类threading.Thread中的run方法
    #run方法中该线程的具体执行逻辑
    def run(self):
        print("启动线程")
        time.sleep(3)
        print("退出线程")


#实例化自定义线程类的对象
t1 = MyThread()

'''调用父类中的start方法，start方法会去调用run方法
而我们重写了父类中的run方法，所以会去执行我们这个自定义线程类中的run方法
'''
t1.start()





