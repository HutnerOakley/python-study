#coding=utf-8

import time
import threading

#获取当前线程对象
t = threading.current_thread()
#通过getName方法获取线程名称
print(t.getName())
#通过name属性获取线程名称
print(t.name)
#判断线程是否被激活
print(t.isAlive())
print(t.is_alive())



def mythread(num):
    '''
    获取线程的名称
    :param num:
    :return: None
    '''
    time.sleep(1)
    t = threading.current_thread()
    print("当前线程的名称为：%s 激活状态为：%s" %(t.getName(),t.is_alive()))
    print(num)

'''
利用for循环启动多个线程
并且利用name参数设置线程的名称
'''
for i in range(0,5):
    t1 = threading.Thread(target=mythread,args=(i,),name="threadtest-%d"%i)
    t1.start()



def func1():
    for i in range(0,3):
        time.sleep(1)
        print("func1")

t2 = threading.Thread(target=func1)
t2.setDaemon(True)
t2.start()
print("helloworld")
time.sleep(2)
print("end...")