# coding=utf-8

import threading
import time

lis = [11, 22]


def func1(temp):
    temp.append(33)
    print("func1中的全局变量值：%s" %str(temp))

def func2(temp):
    print("func2的全局变量值：%s" %str(temp))

def test():
    '''
    target为目标函数，args为目标函数的参数，必须为元祖型
    :return: None
    '''
    t1 = threading.Thread(target=func1,args=(lis,))
    t2 = threading.Thread(target=func2,args=(lis,))
    t1.start()

    # t1.join()
    #延时1s是为了让线程1先执行完成对全局变量的操作,也可以使用join方法来实现
    # time.sleep(1)

    t2.start()
    time.sleep(1)

    #输出最终的全局变量
    print("最终的变量为：%s" %str(lis))


if __name__ == '__main__':
    test()
