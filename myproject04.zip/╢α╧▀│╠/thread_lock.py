#coding=utf-8

import threading
import time

lock = threading.Lock() #获取锁这个对象

a = 0

def add():
    global a
    lock.acquire() #获取锁 locked，独占
    a+=1
    time.sleep(0.5)
    lock.release() #释放锁
    print("%s adds a to : %d" %(threading.current_thread().getName(),a))

def test():
    '''
    利用循环开启10个进程，将进程名设置为thread-的格式
    :return: None
    '''
    for i in range(0,10):
        t1 = threading.Thread(target=add,name="thread-%d" %i)
        t1.start()

if __name__ == '__main__':
    test()