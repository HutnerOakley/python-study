# coding=utf-8

# 阶乘
'''
5!=5*4*3*2*1
3!=3*2*1
找到这个式子规律 f(n) = f(n-1)*n
这个规律的式子就是我们的递归表达式
我们递归的边界条件时f(1)=1,当n=1时，递归结束。
'''


# def func1(n):
#     m = 0
#     if n == 1:
#         return 1
#     elif n == 0:
#         return 1
#     else:
#         m = func1(n - 1) * n
#         return m
#
#
# print(func1(4))  # 24


#菲波那锲数列
'''
1 1 2 3 5 8 13 21 34 55 89 ... (n-1) (n-2) n
这个式子的规律是f(n)=f(n-1)+f(n-2)
递归的边界条件是f(1)=1 f(2)=1
'''
def func2(n):
    if n == 1:
        return 1
    elif n == 2:
        return 1
    else:
        return func2(n-1)+func2(n-2)
#输出第10个斐波那契数列
print(func2(10))