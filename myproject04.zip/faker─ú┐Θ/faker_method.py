# coding=utf-8

from faker import Faker

faker1 = Faker("zh_CN")
print("name:",faker1.name())
print("address:",faker1.address())
print("phone:",faker1.phone_number())
print("ssn:",faker1.ssn())
print("url:",faker1.url())
print("image_url:",faker1.image_url())
print("random_str",faker1.pystr())
print("text",faker1.text())




