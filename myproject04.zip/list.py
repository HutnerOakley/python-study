list1 = [1, "2", 3, 4, "qwe"]
print(list1[0:3])
print(list1[::-1])


