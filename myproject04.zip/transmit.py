# coding=utf-8
def func(a):
    a = 11
    print(f"函数中{a}")
a = 10
func(10)
print(f"函数外{a}")




def func1(a_list):
    a_list.append(4)
    print(f"函数中{a_list}")

a_list = [1, 2, 3]
func1(a_list)
print(f"函数外{a_list}")


