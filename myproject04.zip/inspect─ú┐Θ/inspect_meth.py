#coding=utf-8

import inspect
import unittest

def func(a,b):
    """
    加法
    :param a:
    :param b:
    :return:
    """
    print("加法")
    return a + b

#获取方法的源码
print(inspect.getsource(func))
#获取方法所在文件的路径
print(inspect.getsourcefile(func))
#获取方法的文档注释信息
print(inspect.getdoc(func))

#获取当前方法的参数
print(inspect.signature(func))

#获取模块中的所有成员
'''
getmembers方法会以名称，值的
形式返回对象的所有成员
'''
for i,j in inspect.getmembers(unittest):
    """
    获取该模块的所有类
    """
    if inspect.ismodule(j):
        print("是否是一个模块:"+j.__name__)
    if inspect.isclass(j):
        print("是否是一个类:"+j.__name__)
    if inspect.ismethod(j):
        print("是否是一个方法:"+j.__name__)
