# coding=utf-8

class Person:

    def move(self):
        print("移动")

    def test(self):
        print("姓名:{}".format(self.name))
        print("年龄:{}".format(self.age))

    #当对象呗删除时，会调用这个方法
    def __del__(self):
        print("调用了这个del方法")


student = Person()
student.name = "张飞"
student.age=18
student.move()
student.test()