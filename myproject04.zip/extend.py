# coding=utf-8

class Person(object):

    def move(self):
        print("移动")

    def study(self):
        print("学习")


class Man(Person):
    def say(self):
        print("说")


a = Man()  # 实话Man这个类
a.say()  # 调用Man类中的方法
a.study()  # 调用父类Person中的方法
a.move()  # 调用父类中Person的方法


class Father(object):

    def __init__(self, name):
        self.name = name
        print("父类构造方法")

    def getName(self):
        return self.name


class Son(Father):

    def __init__(self, name):
        # Father.__init__(self,name)
        super(Son,self).__init__(name)
        self.name = name
        print("子类的构造方法")

    def getName(self):
        return self.name







if __name__ == '__main__':
    son = Son("李四")
    print(son.getName())
