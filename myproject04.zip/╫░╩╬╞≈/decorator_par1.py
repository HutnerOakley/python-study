#coding=utf-8



import time
import logging



logging.basicConfig(format='%(asctime)s - %(levelname)s: %(message)s', level=logging.DEBUG)

#add_logging为装饰器
'''
当装饰器本身有参数时，我们需要有三层结构。
@add_logging(level="warn")=@decorator
'''
def add_logging(level):
    def decorator(func):
        def wrapper(*args,**kwargs):
            if level=="warn":
                logging.warning("%s is running by warning" % func.__name__)
            elif level=="info":
                logging.info("%s is running" % func.__name__)
            func(args,kwargs)  # 将传进来的函数地址，直接执行
        return wrapper
    return decorator

@add_logging(level="warn")
def fun_test(*args,**kwargs):
    print("I am {}".format(args,kwargs))

@add_logging(level="info")
def fun_test1(*args,**kwargs):
    print("I am {}".format(args,kwargs))


if __name__ == '__main__':
    fun_test("laowang",age=18)
    fun_test1("laozhang",age=19)