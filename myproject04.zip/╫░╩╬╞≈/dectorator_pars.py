#coding=utf-8



def fun1(func):
    print("enter func1")
    def inner_fun1():
        print("enter inner_fun1")
        func()
        print("exit inner_fun1")
    return inner_fun1

def fun2(func):
    print("enter func2")
    def inner_fun2():
        print("enter inner_fun2")
        func()
        print("exit inner_fun2")
    return inner_fun2

#想当于：fun_test=fun2(fun1(fun_test))  此时fun1(fun_test)=inner_fun1
'''
@fun1
fun1(fun_test)
'''
@fun2
@fun1
def fun_test():
    print("helloworld")


fun_test()