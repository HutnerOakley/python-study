# coding=utf-8
import time


def runtime(func):
    def wrapper():
        print("wapper()函数开始执行")
        before = time.time()
        func()
        after = time.time()
        return after - before
    return wrapper


@runtime
def func1():
    list1 = []
    for i in range(0, 10):
        time.sleep(0.1)
        list1.append(i)
    # print(list1)
    return list1

@runtime
def func2():
    print("func2开始执行")
    time.sleep(2)
    print("执行结束")


if __name__ == '__main__':
    print(func1())
    print(func2())