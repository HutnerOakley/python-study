# coding=utf-8


import logging

logging.basicConfig(format='%(asctime)s - %(levelname)s: %(message)s', level=logging.DEBUG)

#add_logging为装饰器
def add_logging(func):
    def wrapper():
        logging.info("%s is running" % func.__name__)
        func()  # 将传进来的函数地址，直接执行
    return wrapper

@add_logging
def fun_test():
    print("I am fun_test")


if __name__ == '__main__':
    fun_test()
    # wrapper_test = add_logging(fun_test) #调用add_logging(fun_test)回返回一个wrappe对象，然后将这个对象赋给我们的wrapper_test
    # wrapper_test() #执行wrapper_test()就相当于执行了wrapper()
