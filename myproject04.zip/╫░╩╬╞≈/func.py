# coding=utf-8

#函数中传递函数
def func1(a,b):
    print(f"函数{func1.__name__}在被执行")
    return a+b

def func2(func,c,d):
    print(f"函数{func2.__name__}在被执行")
    return func(c,d)

print(func2(func1,3,5))


#函数中定义函数
def func3():
    print(f"函数{func3.__name__}在被执行")

    def func4():
        print(f"函数{func4.__name__}在被执行")
    func4()

func3()

#函数中返回函数
def func5(a):
    print(f"函数{func5.__name__}在被执行")

    def func6(b):
        print(f"函数{func6.__name__}在被执行")
        return a + b
    return func6 #返回的是func6()这个函数在内存中的地址，也就是一个对象。

func6=func5(5)
print(func6(8))
