# coding=utf-8


import logging

logging.basicConfig(format='%(asctime)s - %(levelname)s: %(message)s', level=logging.DEBUG)

#add_logging为装饰器
def add_logging(func):
    def wrapper(*args,**kwargs):
        logging.info("%s is running" % func.__name__)
        func(args,kwargs)  # 将传进来的函数地址，直接执行
    return wrapper

@add_logging
def fun_test(*args,**kwargs):
    print("I am {}".format(args,kwargs))
    print(*args,**kwargs)


if __name__ == '__main__':
    fun_test("laowang",12,13,age=18)