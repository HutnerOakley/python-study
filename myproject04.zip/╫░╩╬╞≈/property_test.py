# coding=utf-8

class DataSet(object):
    def __init__(self):
        self.__name = "laowang"
        self.__age = 18  # 定义属性的名称

    @property
    def name(self):
        return self.__name

    @property
    def age(self):  # 方法中加入property后，这个方法相当于一个属性，这个属性可以让用户使用，但是不能进行修改
        return self.__age


test = DataSet()
print(test.name)
print(test.age)


class Test(object):

    #不加property就是普通的实例方法
    def say(self):
        print("helloWorld")

    #加了property，就是一个只读属性
    @property
    def say_test(self):
        return "helloWorld2"


test = Test()
test.say() #对象直接调用方法
print(test.say_test) #对象调用属性


class Student(object):

    @property
    def age(self):  # 只读属性
        return self._age

    @age.setter  # 要进行修改需要利用setter方法
    def age(self, value):
        if not isinstance(value, int):  # 年龄不是整数抛出异常
            raise ValueError("年龄必须是整数")
        if value < 0 or value > 200:  # 年龄不是0到200岁之间抛出异常
            raise ValueError("年龄需要在0到200岁之间")
        self._age = value


s1 = Student()
s1.age = 20
print(s1.age)
