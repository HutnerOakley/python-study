# coding=utf-8

import traceback

# try:
#     a = 1
#     print(a/1)
# except Exception:
#     print("被除数不能为0")
#
# try:
#     a = int(input("请输入一个数"))
#     print(a/1)
# except:
#     print("请输入正确的数")
# else:
#     print("没有异常")
# finally:
#     print("finally")


try:
    a =input("请输入一个数")
    b = input("请再输入一个数")
    if (not a.isdigit()):
        raise ValueError("a必须是数字")  # 抛出a不是数字的异常
    if (not b.isdigit()):
        raise KeyError("b必须是数字")  # 抛出b不是数字的异常

except ValueError as e:
    print("触发了ValueError", repr(e))  # repr()函数是将一个对象转化为strin格式

except KeyError as e:
    print("触发了KeyError", repr(e))

# try:
#     print(1/0)
# except Exception as e:
#     print(e)
#     traceback.print_exc()
#     error = traceback.format_exc()
#     print(error)
# print("123")
