# coding=utf-8
def func(a, b, c):
    return a + b + c


print(func(1, 2, 3))


def func1(x, y, z=3):
    return x + y + z


print(func1(4, 9))


def func2(x, y, z):
    return x + y + z


print(func2(z=4, x=1, y=5))


def func3(x, y, *z):
    print(x, y, z)


func3(1, 5, 20, 30, 40, 50)


def func4(a, b, **c):
    print(a, b, c)


func4(10, 20, name="xiaogan", age=18, sex=1)


def func5(*args, **kwargs):
    print(args,end=" ")
    print(kwargs)


func5(1, 10, 30, "qwe", "asd", person=10, sex=1, name="hangman")
