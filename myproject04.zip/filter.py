list1 = [1,2,3,4,5,6]
new_list1 = filter(lambda x:x%2==0,list1)
print(list(new_list1))

def first_name(x):
    if x.startswith("A"):
        return True
    else:
        return False
name = ["Alex","ASD","ZXC"]
new_name = filter(first_name,name)
print(list(new_name))

