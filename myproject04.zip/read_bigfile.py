# coding=utf-8


with open(r"F:\project\myproject04\file\test.txt","r") as f:
    while True:
        sout = f.read(5)
        print(sout)
        if not sout: #如果读取的内容不存在则跳出循环
            break
        # if sout is None:
        #     break
        # if not sout is None:
        #     break