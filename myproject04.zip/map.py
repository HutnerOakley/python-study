# list1 = [1,2,3,4,5]
# new_list = map(lambda x:x*2,list1)
# print(list(new_list))


list2 = ["qwe","asd","zxc"]
new_list2 = map(lambda x: x.upper(),list2)
print(list(new_list2))


list3 = [2,4,6,8]
list4 = [1,3,5,7]
new_list5 = map(lambda x,y:x+y,list3,list4)
print(list(new_list5))


