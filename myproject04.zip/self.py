# coding=utf-8

class Person:

    def study(self):
        print("xuexi")

    def move(self):
        print("移动")

    def test(self):
        print("年龄：{}".format(self.age)) #在类中调用对象的属性
        print("姓名:{}".format(self.name))
        print("性别:{}".format(self.sex))

#实例化对象
student = Person()

student.sex = 1
student.name = "张三"
student.age = 18
student.test()

print("学生姓名：{}".format(student.name))
print("学生年龄:{}".format(student.age))