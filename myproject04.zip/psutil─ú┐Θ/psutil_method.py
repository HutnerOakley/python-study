#coding=utf-8

import psutil
import time

#获取cpu的数量
print(psutil.cpu_count())

#获取cpu中每个cpu的当前利用率
'''
psutil.cpu_percent方法返回
当前系统CPU的浮点值,以百分比表示的利用率。
当percpu为True时，返回每个CPU的利用率百分比
'''
# for i in range(0,5):
#     time.sleep(1)
#     print(psutil.cpu_percent(interval=1,percpu=True))


#获取内存的使用情况
'''
virtual_memory()方法返回一个元祖
其中存放了有关系统内存的使用情况
'''
memory = psutil.virtual_memory()
print(memory) #svmem(total=8317554688, available=1389776896, percent=83.3, used=6927777792, free=1389776896)
#可用的总物理内存的情况
print(memory.total) #8317554688
#使用的内存情况
print(memory.used) #6927777792
#空闲的内存情况
print(memory.free) #1389776896

#获取磁盘利用列表，返回的是磁盘的总空间，使用了多少，剩余多少，以及使用率
print(psutil.disk_usage("C:\\")) #sdiskusage(total=75162574848, used=48556544000, free=26606030848, percent=64.6)

#获取当前网络的IO情况，返回一个元祖
print(psutil.net_io_counters()) #snetio(bytes_sent=13501124, bytes_recv=261154820, packets_sent=142208, packets_recv=275667, errin=0, errout=0, dropin=0, dropout=0)

#获取网络接口信息,与每个NIC（网络接口）关联的地址
print(psutil.net_if_addrs())

#获取所有进程PID
print(psutil.pids())
for i in psutil.pids():
    pid= psutil.Process(i)
    print(pid.name(),pid.status())