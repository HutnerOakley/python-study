# coding=utf-8

import collections

#创建双向队列
de = collections.deque()

'''
队列有点类似于列表
可以使用一些列表的方法
'''
for i in range(0,4):
    de.append(i)

print(len(de)) #4
print(de[0]) #0
print(de[-1]) #3

#往左边添加一个元素
de.appendleft(5)
print(de) #deque([5, 0, 1, 2, 3])
de.appendleft(6)
print(de) #deque([6, 5, 0, 1, 2, 3])

#插入指定位置
de.insert(0,"a")
print(de) #deque(['a', 6, 5, 0, 1, 2, 3])

#还可以限制队列最大的长度，当超过长度时会删除一个元素
d1 = collections.deque(maxlen=3)
for i in range(0,3):
    d1.append(i)

print(d1) #deque([0, 1, 2], maxlen=3)
d1.append(3)
print(d1) #deque([1, 2, 3], maxlen=3)
