#coding=utf-8

from collections import *

list1 = ["a","a","b","b","c","c","d"]

#Counter方法计数功能
count = Counter(list1)
print(count)  #Counter({'a': 2, 'b': 2, 'c': 2, 'd': 1})
print(count.keys()) #dict_keys(['a', 'b', 'c', 'd'])
print(count.values()) #dict_values([2, 2, 2, 1])
print(count["a"]) #2

#most_common()方法返回一个列表，包含counter中前n个元素
#返回排名前两名的元素
print(Counter(list1).most_common(2)) #[('a', 2), ('b', 2)]