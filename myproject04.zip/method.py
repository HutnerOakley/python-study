# coding=utf-8

class Person(object):

    def add(self, x, y): #实例方法
        print("实例方法")
        print(x+y)

    @staticmethod #加了staticmethod装饰器为静态方法
    def test():
        print("静态方法")

    @classmethod #加了classmethod装饰器为类方法
    def func(cls):
        print("类方法")

if __name__ == '__main__':
    Person.test() #类调用静态方法
    Person.func() #类调用类方法
    person = Person()
    person.add(1,2) #对象调用实例方法
    person.func() #对象调用类方法
    person.test() #对象调用静态方法
# Person.add(1,2)
