# def func():
#     return  1 == 2
# result = func()
# print(result)
#
# result1 = lambda : 1 == 2
# print(result1())


# def func1(x,y,z):
#     return x+y+z
# print(func1(1,2,3))
#
# a = lambda x,y,z: x+y+z
# print(a(1,2,3))

def func2(x,y):
    if x>y:
        return x
    else:
        return y
print(func2(2,3))

func = lambda x,y:x if x >y else y
print(func(2,3))