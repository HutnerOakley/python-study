# coding=utf-8


file = open(r"F:\project\myproject04\file\demo.txt","w")
file.write("您好")
file.close()