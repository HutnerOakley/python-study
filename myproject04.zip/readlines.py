# encoding=utf-8

file = open(r"F:\project\myproject04\file\test.txt")
f = file.readlines() #读取文件中的所有行，返回一个字符串列表
print(f)

#通过for循环遍历列表来读取
for i in f:
    print(i,end='')
file.close()