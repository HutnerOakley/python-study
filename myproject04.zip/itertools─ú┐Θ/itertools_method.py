#coding=utf-8

import itertools


'''
itertools是用来创建和使用迭代器
itertools.count方法会创建一个无限迭代器，
其中count(strat,step) -->开始，开始+步骤，开始+2*步骤...
'''
# 计数输出奇偶数
for i in itertools.count(start=1, step=2):
    if i > 100:
        break
    else:
        print(i)

'''
itertools.cycle方法需要传入一个可迭代对象,
它会创建一个无限迭代器
所以给一个终止条件避免无限迭代
'''
list1 = [1, 2, 3, 4, 5,6]
num = 0
for i in itertools.cycle(list1):
    print(i)
    num = num + 1
    if num == 12:
        break

'''
itertools.repeat方法需要传入一个可迭代对象,
它会创建一个无限迭代器
但是它可以传入一个参数n，控制迭代的次数
'''
for i in itertools.repeat("hello world", 3):
    print(i)


'''
itertools.chain方法将多个迭代对象连接起来
将传入的多个可迭代对象拼接成一个迭代器，
按照传入的顺序进行迭代
'''
list2 = [1,2,3,4,5]
toup = ("a","b","c","d","e")
str1 = "helloworld"

for i in itertools.chain(list2,toup,str1):
    print(i)

'''
itertools.combinations方法用来生成一个新的组合
需要传入一个对象，元素组合的数量,
combinations方法生成的组合中的元素是不重复的
combinations_with_replacement方法生成的组合中的元素是可以重复的
'''
x = itertools.combinations(list2,2)
for i in x:
    print(i,end=" ")
x1 = itertools.combinations_with_replacement(list2,2)
print()
for i in x1:
    print(i,end=" ")

print()

'''
笛卡尔积就是计算两个组合乘积的所有可能性
itertools.product方法就可以帮我们算出两个组合的
笛卡尔积
'''
list3 = [1,2,3]
list4 = [200,400,600]
for i in itertools.product(list3,list4):
    print(i)

#直接利用for循环来做
for i in list3:
    for j in list4:
        print((i,j))

