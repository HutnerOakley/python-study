#coding=utf-8

import fileinput
import chardet


for i in fileinput.input(files=['./file/demo.txt','./file/test.txt'],mode="r",openhook=fileinput.hook_encoded("gbk")):
    print(chardet.detect(i.encode()))
    print(i)