# coding =utf-8
import linecache

f = linecache.getline("./file/img.png", 10)
print(f)
