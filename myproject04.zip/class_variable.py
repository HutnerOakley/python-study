# coding=utf-8

class Person(object):
    num = 100 #类变量

    def __init__(self):
        self.name= "xiaozhang" #实例变量
        self.age = 18
        self.sex = 1

    def func(self):
        total  = 2
        self.a = 100
        self.b = 200

    def add(self):
        self.x = 10
        self.y = 20
        self.c = 30
        self.d = 40
        return self.x+self.y

#实例化类
student = Person()
student.add()
print(student.x,student.y,student.c,student.d,student.age,student.name) #实例变量只能被对象引用
print(Person.num) #类变量可以被类直接使用
print(student.num) #类变量也可以被对象使用

