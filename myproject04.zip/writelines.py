#coding=utf-8

#先读取文件内容，生成一个列表
file = open(r"F:\project\myproject04\file\test.txt","r")
f= file.readlines()
print(f)
file.close()

#然后再通过writelines函数将文件写入到另一个文件中
file1 = open(r"F:\project\myproject04\file\test123.txt","w")
f1 = file1.writelines(f)
file1.close()
