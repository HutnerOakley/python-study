#coding=utf-8

import sys

#脚本执行参数列表
for i in sys.argv:
    print(i)

#搜索模块的路径
for i in sys.path:
    print(i)

'''
input和print函数其实原理就是调用sys中的标准输入输出方法
'''

#sys.stdin与input()
str = input("请输入:")
print(str)

##等价于
print("请输入:",) #逗号表示不换行
str1 = sys.stdin.readline()[:-1] #-1表示可以抛弃输入流中的'\n' 换行符


#sys.stdout与print()
sys.stdout.write("hello"+'\n')
##等价于
print("hello")