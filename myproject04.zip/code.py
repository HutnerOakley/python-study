#coding=utf-8


name = "张三"

name1 = name.encode("utf-8") #将name以utf-8的格式编码成
print(name1)
print(type(name1))

name2 = name.encode("gbk")
print(name2)
print(type(name2))

name3 = name1.decode("utf-8")
name4 = name2.decode("gbk")
print(name3,name4)
print(type(name3))
print(type(name4))